﻿using System;

public class Class1
{
	public Class1()
	{

         private string name;
    private decimal balance;

    public string Name { get; set; }

    public decimal Balance
    {
        get { return balance; }
        private set
        {
            if (value > 0.0m)
            {
                balance = value;
            }
        }
    }

    public Account(string nombreCuenta, decimal balance)
    {
        NombreCuenta = nombreCuenta;
        Balance = balance;
    }

    public void deposito(decimal cantidad)
    {
        if (cantidad > 0.0m)

        Balance = cantidad + Balance;
        Console.WriteLine("Deposito completado");
        
        else
        {
            Console.WriteLine("El monto debe ser mayor que 0");
        }
    }

    public void retiro (decimal cantidad)
    {
        if (cantidad >= Balance)
        {
            Balance = Balance - cantidad;
        }
        else
        {
            Console.WriteLine("El monto no debe exceder el balance.");
        }
    }
}