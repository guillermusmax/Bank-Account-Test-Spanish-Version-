﻿using Banco;
//Account cuenta1 = new Account("Bruno Mars", 500.00m);
Account cuenta = new Account("El Bellezo", 1000.00m);

//Console.WriteLine($"El balance de {cuenta1.Name} es {cuenta1.Balance}");
//Console.WriteLine($"El balance de {cuenta2.Name} es {cuenta2.Balance}");

//Console.WriteLine("\nIntroduzca a cantidad a depositar a la cuenta: ");
//decimal deposito = decimal.Parse(Console.ReadLine());

//Console.WriteLine($"Depositando  {deposito:C} al balance de la cuenta: {cuenta2.Balance}");
//cuenta2.deposito(deposito);

//Console.WriteLine($"El balance de {cuenta2.Name} es {cuenta2.Balance:C}");
Start:
Console.WriteLine("Que tipo de cuenta desea consultar\n1- Corriente\n2- Ahorro");
int Seleccion = Convert.ToInt32(Console.ReadLine());

switch (Seleccion)
{
    case 1:
        Console.Clear();
        Console.WriteLine("Cuenta Corriente");
        Console.WriteLine("Que desea realizar\n1- Consulta de su balance\n2- Retiro\n3- Deposito");
        Seleccion = Convert.ToInt32(Console.ReadLine());
        switch (Seleccion)
        {
            case 1:
                Console.Clear();
                Console.WriteLine("Su balance actual es: " + cuenta.Balance);
                break;
               
            case 2:
                Console.Clear();
                Console.WriteLine("Que cantidad desea retirar");
                decimal retiro = decimal.Parse(Console.ReadLine());
                Console.WriteLine($"Retirando {retiro:C} al balance de la cuenta: {cuenta.Name}");
                cuenta.Retiro(retiro);
                Console.WriteLine($"El nuevo balance es: {cuenta.Balance}");
                break;
            case 3:
                Console.Clear();
                Console.WriteLine("Que cantidad desea depositar");
                decimal deposito = decimal.Parse(Console.ReadLine());
                Console.WriteLine($"Depositando {deposito:C} al balance de la cuenta: {cuenta.Balance}");
                cuenta.Deposito(deposito);
                Console.WriteLine($"El balance de {cuenta.Name} es {cuenta.Balance:C}");
                break;
        }
        break;
    case 2:
        Console.Clear();
        Console.WriteLine("Cuenta de Ahorros");
        Console.WriteLine("Que desea realizar\n1- Consulta de su balance\n2- Retiro\n3- Deposito");
        Seleccion = Convert.ToInt32(Console.ReadLine());
        switch (Seleccion)
        {
            case 1:
                Console.Clear();
                Console.WriteLine("Su balance actual es: " + cuenta.Balance);
                break;

            case 2:
                Console.Clear();
                Console.WriteLine("Que cantidad desea retirar");
                decimal retiro = decimal.Parse(Console.ReadLine());
                Console.WriteLine($"Retirando {retiro:C} al balance de la cuenta: {cuenta.Name}");
                cuenta.Retiro(retiro);
                Console.WriteLine($"El nuevo balance es: {cuenta.Balance}");
                break;
            case 3:
                Console.Clear();
                Console.WriteLine("Que cantidad desea depositar");
                decimal deposito = decimal.Parse(Console.ReadLine());
                Console.WriteLine($"Depositando {deposito:C} al balance de la cuenta: {cuenta.Balance}");
                cuenta.Deposito(deposito);
                Console.WriteLine($"El balance de {cuenta.Name} es {cuenta.Balance:C}");
                break;
        }
        break;
}
Console.WriteLine("Desea realizar otra transaccion?\n1- si\n2- no");
Seleccion = Convert.ToInt32(Console.ReadLine());
switch (Seleccion)
{
    case 1:
        Console.Clear();
        goto Start;
        break;
    case 2:
        Console.Clear();
        Console.WriteLine("Feliz resto del dia ;)");
        break;
}