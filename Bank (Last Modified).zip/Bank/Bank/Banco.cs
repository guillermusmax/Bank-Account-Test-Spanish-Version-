﻿using System;


namespace Banco
{

    internal class Account
    {
        private string name;
        private decimal balance;

        public string Name { get; set; }

        public decimal Balance
        {
            get { return balance; }
            private set
            {
                if (value > 0.0m)
                {
                    balance = value;
                }
            }
        }

        public Account(string name, decimal balance)
        {
            Name = name;
            Balance = balance;
        }

        public void Deposito(decimal cantidad)
        {
            if (cantidad > 0.0m)
            {
                Balance = Balance + cantidad;
                Console.WriteLine("Deposito completado.");
            }
            else
            {
                Console.WriteLine("El monto debe ser mayor que 0.");
            }
        }

        public void Retiro(decimal cantidad)
        {
            if (cantidad > Balance)
            {
                Console.WriteLine("No puede sobrepasar");
            }
            else
            {
                Balance = Balance - cantidad;
                Console.WriteLine("Retiro exitoso");
            }
        }
    }
}